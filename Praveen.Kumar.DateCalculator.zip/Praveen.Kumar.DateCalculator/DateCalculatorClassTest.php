<?php
use PHPUnit\Framework\TestCase;

class DateCalculatorTest extends TestCase
{
    private $from_date;
    private $to_date;

    public function testEmpty()
    {
        $this->from_date = '';
        $this->to_date = '';
        $this->assertEmpty($from_date);
        $this->assertEmpty($to_date);
    }

    /**
     * @depends testEmpty
     */
    public function calculateNumberOfDays()
    {
        $this->assertNotEmpty($this->from_date);
        $from_date_days = $this->assertEquals(737367.965, $this->getNumberOfDaysGivenDate('01-10-2018'));
        $this->assertNotEmpty($this->to_date);
        $to_date_days = $this->assertEquals(737396.965, $this->getNumberOfDaysGivenDate('30-10-2018'));
        
        //After subtracting you will get the number of days between two dates
        $days = $from_date_days - $to_date_days;

        //Return the number of days between the two dates
        //use the floor of the result of any division
        return floor($days);
    }

    /**
     * @depends calculateNumberOfDays
     */
    public function getNumberOfDaysBetweenTwoDates() {
        $days = str_replace("-","", $this->calculateNumberOfDays());
        $this->assertEmpty($days);
        return $this->assertEquals('29', $days);
	   
	}
}
?>
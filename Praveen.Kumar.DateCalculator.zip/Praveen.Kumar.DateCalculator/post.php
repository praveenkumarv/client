<?php
require('DateCalculatorClass.php');

if(!empty($_POST['fromDate']) && !empty($_POST['toDate'])){
    $fromDate = $_POST['fromDate'];
    $toDate = $_POST['toDate'];
}else{
    echo 'From date and To date fields are required!.';
    exit;
}
$dateObj = new DateCalculator($fromDate,$toDate);
echo $dateObj->getNumberOfDaysBetweenTwoDates(). ' Days';

?>